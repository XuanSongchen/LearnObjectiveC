//
//  main.m
//  Homework_Chapter6
//
//  Created by XuanSongchen on 4/9/16.
//  Copyright © 2016 Xuan Songchen. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        
        int p[151] = {0};
        for (int i = 2; i <= 150; i++) {
            for (int j = i; i * j <= 150; j++) {
                p[i * j] = 1;
            }
        }
        int counter = 1;
        for(int i = 2; i <= 150; i++) {
            if (p[i] == 0) {
                NSLog(@"第%d个质数是%d", counter++, i);
            }
        }
        
    }
    return 0;
}
